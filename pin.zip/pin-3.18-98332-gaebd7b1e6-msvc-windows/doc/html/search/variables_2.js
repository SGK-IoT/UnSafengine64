var searchData=
[
  ['max_5fclient_5ftls_5fkeys',['MAX_CLIENT_TLS_KEYS',['../group__PIN__THREAD__API.html#gabd941659bf3eebac5b1ff8b59df872b7',1,'LEVEL_PINCLIENT']]],
  ['max_5fwindows_5fexception_5fargs',['MAX_WINDOWS_EXCEPTION_ARGS',['../group__EXCEPTION__API.html#ga3e0b682c9f46bdf1e0dcfa3efd532e52',1,'LEVEL_BASE']]]
];
