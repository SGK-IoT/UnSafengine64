var searchData=
[
  ['child_5fprocess',['CHILD_PROCESS',['../group__CHILD__PROCESS__API.html#ga17aa0357dbaaec79a971207a6d4ec281',1,'LEVEL_PINCLIENT']]],
  ['context',['CONTEXT',['../group__CONTEXT__API.html#ga73f8f88949aaecf53a6d23f56399c676',1,'types_vmapi.H']]],
  ['context_5fchange_5fcallback',['CONTEXT_CHANGE_CALLBACK',['../group__PIN__CONTROL.html#ga8f39acc1effd9b2d81b9e26762337070',1,'LEVEL_PINCLIENT']]]
];
