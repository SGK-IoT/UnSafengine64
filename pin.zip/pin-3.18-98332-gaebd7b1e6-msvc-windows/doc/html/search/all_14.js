var searchData=
[
  ['vsyscall_5fnr',['VSYSCALL_NR',['../group__INS__BASIC__API__GEN__IA32.html#ga6b297bcc45088de9d96bacd155f4d103',1,'LEVEL_CORE']]]
];
