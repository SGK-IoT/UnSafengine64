var searchData=
[
  ['fast_20buffering_20apis',['Fast Buffering APIs',['../group__BUFFER__API.html',1,'']]],
  ['follow_20child_20process_20api',['Follow Child Process API',['../group__CHILD__PROCESS__API.html',1,'']]]
];
