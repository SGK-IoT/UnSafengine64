var searchData=
[
  ['memory_5faddr_5ftrans_5fcallback',['MEMORY_ADDR_TRANS_CALLBACK',['../group__PIN__CONTROL.html#ga59a53cc4fdf602553ab60f7ee4ca4c00',1,'LEVEL_PINCLIENT']]]
];
