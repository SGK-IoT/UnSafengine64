var searchData=
[
  ['numberofknobs',['NumberOfKnobs',['../group__KNOB__BASIC.html#gab1e3235efd2b83f2ea8e873231e3aeb3',1,'LEVEL_BASE::KNOB_BASE']]]
];
