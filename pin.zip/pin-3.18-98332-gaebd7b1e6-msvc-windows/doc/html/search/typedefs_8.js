var searchData=
[
  ['physical_5fcontext',['PHYSICAL_CONTEXT',['../group__PHYSICAL__CONTEXT__API.html#ga3c6833a027db42b5d528a0c65cefbc07',1,'types_vmapi.H']]],
  ['pin_5fcallback',['PIN_CALLBACK',['../group__PIN__CALLBACKS.html#ga3ba1895c602cd5b2863b7b75840187a4',1,'LEVEL_PINCLIENT']]],
  ['pin_5fconfiguration_5finfo',['PIN_CONFIGURATION_INFO',['../group__PIN__CONTROL.html#gadfef9e89968c6491114d7ceae51ab61b',1,'LEVEL_PINCLIENT']]],
  ['pin_5fmutex',['PIN_MUTEX',['../group__LOCK.html#ga973e1a7aa00c2222b78a2d929942aa26',1,'LEVEL_BASE']]],
  ['pin_5frwmutex',['PIN_RWMUTEX',['../group__LOCK.html#ga1a83b34b05b377bfe003e5dc6b3bd538',1,'LEVEL_BASE']]],
  ['pin_5fsemaphore',['PIN_SEMAPHORE',['../group__LOCK.html#gacb5ef8f4cc82a8c52b76d4b36833efc9',1,'LEVEL_BASE']]],
  ['pin_5fthread_5fuid',['PIN_THREAD_UID',['../group__PIN__THREAD__API.html#ga057233f26b54f23b1ddb0c0c5e31dba9',1,'types_vmapi.H']]],
  ['predicate',['PREDICATE',['../group__INS__BASIC__API__GEN__IA32.html#ga11ad7033ca136bb3f9f8dca86900df7d',1,'LEVEL_BASE']]],
  ['prepare_5ffor_5ffini_5fcallback',['PREPARE_FOR_FINI_CALLBACK',['../group__PIN__CONTROL.html#gad158b812f88e6cd2d61036b3acae44b4',1,'LEVEL_PINCLIENT']]],
  ['proto',['PROTO',['../group__PROTO__API.html#ga554ff954c3ea33bb537f30e3b500ef1c',1,'types_vmapi.H']]]
];
