var searchData=
[
  ['call_5forder',['CALL_ORDER',['../group__INST__ARGS.html#ga3d1d5f6805cb16d00bce441290ca2212',1,'types_vmapi.H']]],
  ['callingstd_5ftype',['CALLINGSTD_TYPE',['../group__PROTO__API.html#gacfd9f3c8dc22310ce9b9152e8c61b17c',1,'types_vmapi.H']]],
  ['context_5fchange_5freason',['CONTEXT_CHANGE_REASON',['../group__PIN__CONTROL.html#ga8e4e6511a0e09fdc5ec7d6dbf395b3a8',1,'types_vmapi.H']]]
];
